Zhiyuan(James) Zhang 
I pledge my honor that I have abided by the Stevens Honor System. 
Nov 21 2017


Run npm start

all password is hashed, code is in the memory folder, password.js
sotred in the user.js

everytime I run password.js it gives me a unique hashed password so it is great.

go to localhost:3000 and I just used a easy style sheet from the bootstrap website. 