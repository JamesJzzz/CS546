Zhiyuan(James) Zhang
Nov 9 2017
I pledge my honor that I have abided by the Stevens Honor System.

Just do the npm start the server will run on localhost:3000

everything is good from there on.